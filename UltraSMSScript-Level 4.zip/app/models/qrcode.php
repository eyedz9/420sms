<?php

class Qrcode extends AppModel {

	var $name = 'Qrcode';
  


}