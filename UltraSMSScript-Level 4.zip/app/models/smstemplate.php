<?php
class Smstemplate extends AppModel {
	var $name = 'Smstemplate';
	
}
