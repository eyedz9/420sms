<?php
class Dbconfig extends AppModel {
	var $name = 'Dbconfig';
	 
}
