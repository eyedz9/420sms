<?php

class Message extends AppModel {

	var $name = 'Message';



}

