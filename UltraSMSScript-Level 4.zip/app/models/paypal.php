<?php
class Paypal extends AppModel {
	var $name = 'Paypal';
	 
}
