<?php

class Qrcod extends AppModel {

	var $name = 'Qrcod';
  


}