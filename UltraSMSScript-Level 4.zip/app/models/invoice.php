<?php

class Invoice extends AppModel {

	var $name = 'Invoice';

	//The Associations below have been created with all possible keys, those that are not needed can be removed

	


}
