<?php
class Shortlink extends AppModel {
	var $name = 'Shortlink';
}?>