<?php

class ScheduleMessage extends AppModel {

	var $name = 'ScheduleMessage';

	//The Associations below have been created with all possible keys, those that are not needed can be removed

	


}
