<?php 
class Kiosk extends AppModel {

	var $name = 'Kiosk';
	
	



}

 ?>