<?php
define('NUMACCOUNTS',1000);
?>