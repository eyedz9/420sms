<?php
class PaypalIpnAppModel extends AppModel {
  
}
?>