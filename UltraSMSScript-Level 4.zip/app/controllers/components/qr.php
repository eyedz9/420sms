<?php 
App::import('Vendor','Qr',array('file'=>'phpqrcode/qrlib.php'));
class QrComponent extends Object {
}
?>